"""Client Reminders: a tiny desktop app that tells you who to contact again
six months after their last service. Run with:  python app.py
"""
import tkinter as tk
from datetime import date, timedelta
from tkinter import filedialog, messagebox, ttk

from db import Database, parse_date

UPCOMING_DAYS = 14  # "Due soon" also shows anyone due within this many days
DATE_DISPLAY = "%m/%d/%Y"


def fmt(d):
    return d.strftime(DATE_DISPLAY) if d else ""


class ClientDialog(tk.Toplevel):
    """Add / edit window. After it closes, `self.result` is None or a dict."""

    def __init__(self, parent, title, client=None):
        super().__init__(parent)
        self.title(title)
        self.resizable(False, False)
        self.transient(parent)
        self.result = None

        self.name = tk.StringVar(value=client.name if client else "")
        self.phone = tk.StringVar(value=client.phone if client else "")
        self.serviced = tk.StringVar(
            value=fmt(client.last_serviced) if client else fmt(date.today())
        )
        self.notes = tk.StringVar(value=client.notes if client else "")

        frm = ttk.Frame(self, padding=14)
        frm.grid()
        rows = [
            ("Name", self.name),
            ("Phone number", self.phone),
            ("Last serviced (MM/DD/YYYY)", self.serviced),
            ("Notes (optional)", self.notes),
        ]
        first_entry = None
        for i, (label, var) in enumerate(rows):
            ttk.Label(frm, text=label).grid(row=i, column=0, sticky="w", pady=4, padx=(0, 10))
            entry = ttk.Entry(frm, textvariable=var, width=34)
            entry.grid(row=i, column=1, pady=4)
            first_entry = first_entry or entry

        btns = ttk.Frame(frm)
        btns.grid(row=len(rows), column=0, columnspan=2, pady=(12, 0), sticky="e")
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(btns, text="Save", command=self._save).pack(side="right")

        self.bind("<Return>", lambda e: self._save())
        self.bind("<Escape>", lambda e: self.destroy())
        first_entry.focus_set()
        self.grab_set()
        self.wait_window()

    def _save(self):
        name = self.name.get().strip()
        if not name:
            messagebox.showerror("Missing name", "Please enter a name.", parent=self)
            return
        try:
            serviced = parse_date(self.serviced.get())
        except ValueError as e:
            messagebox.showerror("Bad date", str(e), parent=self)
            return
        self.result = {
            "name": name,
            "phone": self.phone.get().strip(),
            "last_serviced": serviced,
            "notes": self.notes.get().strip(),
        }
        self.destroy()


class App(ttk.Frame):
    COLUMNS = (
        ("name", "Name", 190),
        ("phone", "Phone", 130),
        ("serviced", "Last serviced", 100),
        ("contacted", "Last contacted", 105),
        ("due", "Reminder date", 100),
        ("status", "Status", 150),
    )

    def __init__(self, root, db):
        super().__init__(root, padding=10)
        self.db = db
        self.view = tk.StringVar(value="due")
        self.search = tk.StringVar()
        self.search.trace_add("write", lambda *_: self.refresh())
        self._build()
        self.refresh()

    # ---------- layout ----------
    def _build(self):
        top = ttk.Frame(self)
        top.pack(fill="x")
        ttk.Radiobutton(top, text="Due soon", variable=self.view, value="due",
                        command=self.refresh).pack(side="left")
        ttk.Radiobutton(top, text="All clients", variable=self.view, value="all",
                        command=self.refresh).pack(side="left", padx=(10, 0))
        ttk.Entry(top, textvariable=self.search, width=24).pack(side="right")
        ttk.Label(top, text="Search:").pack(side="right", padx=(0, 6))

        self.summary = ttk.Label(self, font=("Segoe UI", 11, "bold"))
        self.summary.pack(anchor="w", pady=(10, 6))

        wrap = ttk.Frame(self)
        wrap.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(
            wrap, columns=[c[0] for c in self.COLUMNS], show="headings", selectmode="extended"
        )
        for key, title, width in self.COLUMNS:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w")
        scroll = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.tree.tag_configure("overdue", background="#fde2e2")
        self.tree.tag_configure("soon", background="#fff4d6")

        self.tree.bind("<Double-1>", lambda e: self.edit_client())
        self.tree.bind("<Delete>", lambda e: self.delete_clients())

        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(10, 0))
        ttk.Button(bar, text="Mark contacted", command=self.mark_contacted).pack(side="left")
        ttk.Button(bar, text="Copy phone", command=self.copy_phone).pack(side="left", padx=6)
        ttk.Separator(bar, orient="vertical").pack(side="left", fill="y", padx=6)
        ttk.Button(bar, text="Add", command=self.add_client).pack(side="left")
        ttk.Button(bar, text="Edit", command=self.edit_client).pack(side="left", padx=6)
        ttk.Button(bar, text="Delete", command=self.delete_clients).pack(side="left")
        ttk.Button(bar, text="Export due list", command=self.export_due).pack(side="right")
        ttk.Button(bar, text="Import CSV", command=self.import_csv).pack(side="right", padx=6)

    # ---------- data -> screen ----------
    def refresh(self):
        today = date.today()
        clients = sorted(self.db.all(), key=lambda c: c.due_date)

        due_now = sum(1 for c in clients if c.days_until_due(today) <= 0)
        shown = clients
        if self.view.get() == "due":
            shown = [c for c in clients if c.days_until_due(today) <= UPCOMING_DAYS]

        q = self.search.get().strip().lower()
        if q:
            shown = [c for c in shown if q in c.name.lower() or q in c.phone.lower()]

        self.tree.delete(*self.tree.get_children())
        for c in shown:
            days = c.days_until_due(today)
            if days < 0:
                status, tag = f"Overdue by {-days} day{'s' if days != -1 else ''}", "overdue"
            elif days == 0:
                status, tag = "Due today", "overdue"
            elif days <= UPCOMING_DAYS:
                status, tag = f"Due in {days} day{'s' if days != 1 else ''}", "soon"
            else:
                status, tag = f"In {days} days", ""
            self.tree.insert(
                "", "end", iid=str(c.id), tags=(tag,) if tag else (),
                values=(c.name, c.phone, fmt(c.last_serviced), fmt(c.last_contacted),
                        fmt(c.due_date), status),
            )

        if due_now:
            self.summary.config(text=f"{due_now} client{'s' if due_now != 1 else ''} to contact now")
        else:
            self.summary.config(text="Nobody is due right now")

    def _selected_ids(self):
        return [int(i) for i in self.tree.selection()]

    def _need_selection(self):
        ids = self._selected_ids()
        if not ids:
            messagebox.showinfo("Select someone", "Click a client in the list first.")
        return ids

    # ---------- actions ----------
    def add_client(self):
        dlg = ClientDialog(self, "Add client")
        if dlg.result:
            self.db.add(**dlg.result)
            self.refresh()

    def edit_client(self):
        ids = self._need_selection()
        if not ids:
            return
        dlg = ClientDialog(self, "Edit client", self.db.get(ids[0]))
        if dlg.result:
            self.db.update(ids[0], **dlg.result)
            self.refresh()

    def delete_clients(self):
        ids = self._selected_ids()
        if not ids:
            return
        if messagebox.askyesno("Delete", f"Delete {len(ids)} client(s)? This can't be undone."):
            self.db.delete(ids)
            self.refresh()

    def mark_contacted(self):
        ids = self._need_selection()
        if not ids:
            return
        if messagebox.askyesno(
            "Mark contacted",
            f"Mark {len(ids)} client(s) as contacted today?\n"
            "Their next reminder will be 6 months from now.",
        ):
            self.db.mark_contacted(ids)
            self.refresh()

    def copy_phone(self):
        ids = self._need_selection()
        if not ids:
            return
        phones = [self.db.get(i).phone for i in ids]
        self.clipboard_clear()
        self.clipboard_append("\n".join(phones))

    def import_csv(self):
        path = filedialog.askopenfilename(
            title="Choose a CSV file", filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            added, skipped, errors = self.db.import_csv(path)
        except (ValueError, OSError) as e:
            messagebox.showerror("Import failed", str(e))
            return
        msg = f"Added {added} client(s).\nSkipped {skipped} duplicate(s)."
        if errors:
            msg += f"\n\n{len(errors)} row(s) had problems:\n" + "\n".join(errors[:10])
            if len(errors) > 10:
                msg += f"\n...and {len(errors) - 10} more"
        messagebox.showinfo("Import finished", msg)
        self.refresh()

    def export_due(self):
        today = date.today()
        due = sorted(
            (c for c in self.db.all() if c.days_until_due(today) <= UPCOMING_DAYS),
            key=lambda c: c.due_date,
        )
        if not due:
            messagebox.showinfo("Nothing to export", "Nobody is due right now.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".csv", initialfile=f"due_{today.isoformat()}.csv",
            filetypes=[("CSV files", "*.csv")],
        )
        if path:
            self.db.export_csv(path, due)


def main():
    try:  # sharper text on high-DPI Windows screens
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass

    root = tk.Tk()
    root.title("Client Reminders")
    root.geometry("900x520")
    root.minsize(760, 380)
    App(root, Database()).pack(fill="both", expand=True)
    root.mainloop()


if __name__ == "__main__":
    main()

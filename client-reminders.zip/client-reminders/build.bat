@echo off
REM Builds dist\ClientReminders.exe  (run from the project folder, with your venv active)
pip install -r requirements-dev.txt
pyinstaller --onefile --windowed --name ClientReminders app.py
echo.
echo Done. Your exe is in the dist folder.
pause

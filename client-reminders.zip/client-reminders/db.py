"""Database and date logic for Client Reminders (no GUI code in here)."""
from __future__ import annotations

import csv
import os
import re
import sqlite3
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Iterable, Optional

from dateutil.relativedelta import relativedelta

REMINDER_MONTHS = 6

DATE_FORMATS = (
    "%Y-%m-%d",
    "%m/%d/%Y",
    "%m/%d/%y",
    "%m-%d-%Y",
    "%B %d, %Y",
    "%b %d, %Y",
)


def data_dir() -> Path:
    """Where the database lives. Kept outside the exe so updates never wipe it."""
    appdata = os.environ.get("APPDATA")  # Windows: C:\Users\<you>\AppData\Roaming
    path = Path(appdata) / "ClientReminders" if appdata else Path.home() / ".client_reminders"
    path.mkdir(parents=True, exist_ok=True)
    return path


def parse_date(text: str) -> date:
    text = text.strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    raise ValueError(f"Couldn't read the date '{text}'. Try MM/DD/YYYY.")


def digits(phone: str) -> str:
    return re.sub(r"\D", "", phone)


@dataclass
class Client:
    id: int
    name: str
    phone: str
    last_serviced: date
    last_contacted: Optional[date]
    notes: str

    @property
    def reminder_base(self) -> date:
        """The six-month clock starts from whichever is later: service or contact."""
        if self.last_contacted and self.last_contacted > self.last_serviced:
            return self.last_contacted
        return self.last_serviced

    @property
    def due_date(self) -> date:
        return self.reminder_base + relativedelta(months=REMINDER_MONTHS)

    def days_until_due(self, today: Optional[date] = None) -> int:
        return (self.due_date - (today or date.today())).days


SCHEMA = """
CREATE TABLE IF NOT EXISTS clients (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT NOT NULL,
    phone          TEXT NOT NULL DEFAULT '',
    last_serviced  TEXT NOT NULL,   -- ISO date, YYYY-MM-DD
    last_contacted TEXT,            -- ISO date or NULL
    notes          TEXT NOT NULL DEFAULT ''
);
"""

# Accepted CSV header names (lowercased, underscores treated as spaces)
COLUMN_ALIASES = {
    "name": {"name", "client", "client name", "customer"},
    "phone": {"phone", "phone number", "number", "phone #", "telephone", "cell"},
    "last_serviced": {
        "last serviced", "last service", "last service date",
        "date last serviced", "date", "service date",
    },
    "notes": {"notes", "note", "comments"},
}


def _map_columns(fieldnames: Iterable[str]) -> dict:
    mapping = {}
    for original in fieldnames:
        key = (original or "").strip().lower().replace("_", " ")
        for target, aliases in COLUMN_ALIASES.items():
            if key in aliases and target not in mapping:
                mapping[target] = original
    return mapping


class Database:
    def __init__(self, path=None):
        self.path = str(path) if path else str(data_dir() / "clients.db")
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute(SCHEMA)
        self.conn.commit()

    # ---------- helpers ----------
    @staticmethod
    def _to_client(row: sqlite3.Row) -> Client:
        return Client(
            id=row["id"],
            name=row["name"],
            phone=row["phone"],
            last_serviced=date.fromisoformat(row["last_serviced"]),
            last_contacted=date.fromisoformat(row["last_contacted"]) if row["last_contacted"] else None,
            notes=row["notes"],
        )

    # ---------- CRUD ----------
    def all(self) -> list[Client]:
        rows = self.conn.execute("SELECT * FROM clients").fetchall()
        return [self._to_client(r) for r in rows]

    def get(self, client_id: int) -> Client:
        row = self.conn.execute("SELECT * FROM clients WHERE id = ?", (client_id,)).fetchone()
        return self._to_client(row)

    def add(self, name: str, phone: str, last_serviced: date, notes: str = "") -> int:
        cur = self.conn.execute(
            "INSERT INTO clients (name, phone, last_serviced, notes) VALUES (?, ?, ?, ?)",
            (name.strip(), phone.strip(), last_serviced.isoformat(), notes.strip()),
        )
        self.conn.commit()
        return cur.lastrowid

    def update(self, client_id: int, name: str, phone: str, last_serviced: date, notes: str = "") -> None:
        self.conn.execute(
            "UPDATE clients SET name = ?, phone = ?, last_serviced = ?, notes = ? WHERE id = ?",
            (name.strip(), phone.strip(), last_serviced.isoformat(), notes.strip(), client_id),
        )
        self.conn.commit()

    def delete(self, client_ids: Iterable[int]) -> None:
        self.conn.executemany("DELETE FROM clients WHERE id = ?", [(i,) for i in client_ids])
        self.conn.commit()

    def mark_contacted(self, client_ids: Iterable[int], when: Optional[date] = None) -> None:
        when = when or date.today()
        self.conn.executemany(
            "UPDATE clients SET last_contacted = ? WHERE id = ?",
            [(when.isoformat(), i) for i in client_ids],
        )
        self.conn.commit()

    # ---------- CSV ----------
    def import_csv(self, path) -> tuple[int, int, list[str]]:
        """Returns (added, skipped_duplicates, error_messages)."""
        added = skipped = 0
        errors: list[str] = []
        existing = {(c.name.lower(), digits(c.phone)) for c in self.all()}

        with open(path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                raise ValueError("That file looks empty.")
            cols = _map_columns(reader.fieldnames)
            missing = [k for k in ("name", "last_serviced") if k not in cols]
            if missing:
                raise ValueError(
                    "Couldn't find these columns in the first row: "
                    + ", ".join(missing)
                    + ".\nThe first row should have headers like: Name, Phone, Last Serviced"
                )

            for line_no, row in enumerate(reader, start=2):
                name = (row.get(cols["name"]) or "").strip()
                raw_date = (row.get(cols["last_serviced"]) or "").strip()
                if not name and not raw_date:
                    continue  # blank row
                if not name:
                    errors.append(f"Row {line_no}: missing name")
                    continue
                try:
                    serviced = parse_date(raw_date)
                except ValueError as e:
                    errors.append(f"Row {line_no} ({name}): {e}")
                    continue

                phone = (row.get(cols["phone"]) or "").strip() if "phone" in cols else ""
                notes = (row.get(cols["notes"]) or "").strip() if "notes" in cols else ""
                key = (name.lower(), digits(phone))
                if key in existing:
                    skipped += 1
                    continue
                self.add(name, phone, serviced, notes)
                existing.add(key)
                added += 1
        return added, skipped, errors

    @staticmethod
    def export_csv(path, clients: Iterable[Client]) -> None:
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["Name", "Phone", "Last Serviced", "Last Contacted", "Due Date", "Notes"])
            for c in clients:
                w.writerow([
                    c.name, c.phone,
                    c.last_serviced.strftime("%m/%d/%Y"),
                    c.last_contacted.strftime("%m/%d/%Y") if c.last_contacted else "",
                    c.due_date.strftime("%m/%d/%Y"),
                    c.notes,
                ])

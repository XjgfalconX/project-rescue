import csv
import os
import sys
import tempfile
import unittest
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from db import Database, parse_date  # noqa: E402


class DbTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")

    def test_due_date_is_six_months_later(self):
        cid = self.db.add("Ann", "555-1234", date(2026, 1, 15))
        self.assertEqual(self.db.get(cid).due_date, date(2026, 7, 15))

    def test_month_end_does_not_overflow(self):
        cid = self.db.add("Bob", "", date(2026, 8, 31))
        self.assertEqual(self.db.get(cid).due_date, date(2027, 2, 28))

    def test_mark_contacted_resets_clock(self):
        cid = self.db.add("Cy", "", date(2026, 1, 1))
        self.db.mark_contacted([cid], date(2026, 7, 5))
        c = self.db.get(cid)
        self.assertEqual(c.last_serviced, date(2026, 1, 1))
        self.assertEqual(c.due_date, date(2027, 1, 5))

    def test_parse_date_formats(self):
        self.assertEqual(parse_date("03/04/2026"), date(2026, 3, 4))
        self.assertEqual(parse_date("2026-03-04"), date(2026, 3, 4))
        with self.assertRaises(ValueError):
            parse_date("soonish")

    def test_csv_import_flexible_headers_and_dupes(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "in.csv")
            with open(p, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                w.writerow(["Client Name", "Phone Number", "Date"])
                w.writerow(["Dee", "(404) 555-0001", "1/5/2026"])
                w.writerow(["Dee", "404-555-0001", "1/5/2026"])  # duplicate
                w.writerow(["Eve", "404-555-0002", "not a date"])  # bad
                w.writerow(["", "", ""])  # blank
            added, skipped, errors = self.db.import_csv(p)
        self.assertEqual((added, skipped, len(errors)), (1, 1, 1))


if __name__ == "__main__":
    unittest.main()
